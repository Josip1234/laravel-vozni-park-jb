<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;
use App\Models\Vozilo;
use App\Models\NamjenaVozila;

use Carbon\Carbon;

class VoziloNamjenaTest extends TestCase
{
    /**
     * A basic feature test example.
     */
    use RefreshDatabase;
    /** @test */
    public function test_example(): void
    {
        $response = $this->get('/');

        $response->assertStatus(200);
    }
     /** @test */
    public function vozilo_pripada_namjeni():void{
        $namjena=NamjenaVozila::create([
            'naziv'=>'Osobno',
        ]);
        $vozilo=Vozilo::create([
            'naziv'=>'BMW',
            'tip'=>'320D',
            'motor'=>'dizel',
            'registracija'=>'ZG1234AA',
            'istek_registracije'=>now()->addYear(),
            'namjenaId'=>$namjena->id,
        ]);
        $vozilo=Vozilo::with('namjena')->first();
        $this->assertNotNull($vozilo->namjena);
        $this->assertEquals('Osobno',$vozilo->namjena->naziv);
    }
}
