<?php echo $__env->make('layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<div class="max-w-6xl mx-auto py-10">

    <div class="flex justify-between items-center mb-6">
        <h1 class="text-2xl font-bold">Popis vozila</h1>
        <a href="<?php echo e(route('vozila.create')); ?>"
           class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
            + Novo vozilo
        </a>
    </div>

    <?php if(session('status')): ?>
        <div class="mb-4 rounded bg-green-50 p-3 text-green-700">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <div class="bg-white shadow rounded p-6">
        <table class="min-w-full border">
            <thead class="bg-gray-50">
            <tr>
                <th class="border px-3 py-2 text-left">ID</th>
                <th class="border px-3 py-2 text-left">Naziv</th>
                <th class="border px-3 py-2 text-left">Tip</th>
                <th class="border px-3 py-2 text-left">Motor</th>
                <th class="border px-3 py-2 text-left">Registracija</th>
                <th class="border px-3 py-2 text-left">Istek</th>
                <th class="border px-3 py-2 text-left">Ostalo</th>
                <th class="border px-3 py-2 text-left">Namjena</th>
                <th class="border px-3 py-2 text-left">Akcije</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $vozila; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="border px-3 py-2"><?php echo e($v->id); ?></td>
                    <td class="border px-3 py-2"><?php echo e($v->naziv); ?></td>
                    <td class="border px-3 py-2"><?php echo e($v->tip); ?></td>
                    <td class="border px-3 py-2"><?php echo e($v->motor); ?></td>
                    <td class="border px-3 py-2"><?php echo e($v->registracija); ?></td>
                    <td class="border px-3 py-2"><?php echo e($v->istek_registracije->format('d.m.Y')); ?></td>
                    <td class="border px-3 py-2">
                        <?php echo e(ceil(now()->diffInDays($v->istek_registracije, false))); ?> dana
                    </td>
                    <td class="border px-3 py-2"><?php echo e($v->namjena?->naziv ?? '—'); ?></td>
                    <td class="border px-3 py-2">
                        <a class="text-blue-600 hover:underline mr-3"
                           href="<?php echo e(route('vozila.edit', $v)); ?>">Uredi</a>

                        <form method="POST" action="<?php echo e(route('vozila.destroy', $v)); ?>"
                              class="inline"
                              onsubmit="return confirm('Obrisati vozilo?');">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="text-red-600 hover:underline">Briši</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="mt-6 flex justify-center">
                    <?php echo e($vozila->links()); ?>

        </div>
    </div>

</div>
<?php echo $__env->make('layouts.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\www\personal\LaravelOOP\voznipark-app\resources\views/vozila/index.blade.php ENDPATH**/ ?>