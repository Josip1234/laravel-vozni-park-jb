php8.3-bcmath
php8.3-cli
php8.3-common
php8.3-curl
php8.3-gd
php8.3-intl
php8.3-mbstring
php8.3-mysql
php8.3-pgsql
php8.3-redis
php8.3-soap
php8.3-sqlite3
php8.3-xml
php8.3-zip
php8.3-swoole
php8.3-fpm<?php /**PATH phar://C:/xampp/www/personal/LaravelOOP/voznipark-app/vendor/fly-apps/dockerfile-laravel/builds/dockerfile-laravel\resources\views/fly/php/packages/8_3_txt.blade.php ENDPATH**/ ?>