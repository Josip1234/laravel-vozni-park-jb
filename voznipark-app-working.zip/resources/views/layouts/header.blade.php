<!doctype html>
<html lang="hr">
<head>
    <meta charset="utf-8">
    @vite(['resources/css/app.css', 'resources/js/app.js'])
    <title>Vozila</title>
</head>
<body class="bg-gray-100">
    @include('layouts.navigation')