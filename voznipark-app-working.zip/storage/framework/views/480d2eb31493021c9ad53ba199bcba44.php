<!doctype html>
<html lang="hr">
<head>
    <meta charset="utf-8">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <title>Vozila</title>
</head>
<body class="bg-gray-100">
    <?php echo $__env->make('layouts.navigation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\www\personal\LaravelOOP\voznipark-app\resources\views/layouts/header.blade.php ENDPATH**/ ?>